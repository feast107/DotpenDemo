#!/usr/bin/env sh
export LD_LIBRARY_PATH=/opt/zbform/Dotpen/lib/
/opt/zbform/Dotpen/DotpenDemo
